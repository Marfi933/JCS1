﻿using JCS07;

string s = "nejaka dlouha veta, kde budu zvetsovat pismena";
Console.WriteLine(s.UpperAfterSpace());

ChessPiece board = new ChessPiece();
board.GetBoard();

DateTime date = new DateTime(1990, 12, 31);
DateTime result = WhenTimesFactor(sonsBirthday, fatherBirthday,
    3);

date.WhenTimesFactor()